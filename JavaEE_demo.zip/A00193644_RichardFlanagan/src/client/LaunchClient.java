package client;

public class LaunchClient {
	public static void main(String[] args) {
		new Client();
	}
}
